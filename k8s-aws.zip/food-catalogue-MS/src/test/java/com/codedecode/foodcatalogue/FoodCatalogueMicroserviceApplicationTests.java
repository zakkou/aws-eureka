/*
package com.codedecode.foodcatalogue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodCatalogueMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/
